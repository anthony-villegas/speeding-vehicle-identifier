import json
import boto3

# zip this file into a file called lambda.zip then run lambda-deploy.py
# This is the main lambda used to interface from s3 to rekognition

rek_client = boto3.client("rekognition")
dynamodb_client = boto3.client('dynamodb')

def lambda_handler(event, context):
    print(event)

    bucket_name = event['Records'][0]['s3']['bucket']['name']
    image_name = event['Records'][0]['s3']['object']['key']
    time = event['Records'][0]['eventTime']

    response = rek_client.detect_text(
        Image={
            "S3Object": {"Bucket":bucket_name, "Name":image_name}, 
        }
    )
    text = json.loads(response['TextDetections'][0]['DetectedText'])
    
    dynamodb_client.put_item(TableName='Violations', 
        Item={'license_plate':{'S': text}, 'time' : {'S':time}
        })

    return {
        'statusCode': 200,
        'body': json.dumps('License plate detected')
    }